package com.chess.pgn;

public class PlayPGNException extends RuntimeException {

    public PlayPGNException(final String message) {
        super(message);
    }

}
