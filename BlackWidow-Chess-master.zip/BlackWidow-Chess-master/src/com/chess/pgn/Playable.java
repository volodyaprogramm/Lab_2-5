package com.chess.pgn;

public interface Playable {

    boolean isValid();

}
