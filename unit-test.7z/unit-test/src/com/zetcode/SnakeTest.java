package com.zetcode;

import javax.swing.*;

import static org.junit.Assert.*;

public class SnakeTest {

    @org.junit.Test
    public void main() {
        JFrame ex = new Snake();
        ex.setVisible(true);
        assertEquals(true);
    }

    private void assertEquals(boolean b) {
    }
}